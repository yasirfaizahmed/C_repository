/*****************************************************
USERDEFINED HEADER FOR SIMPLE OPERATIONS ON SINGLY LINKED LISTS

---include it in the directory where the source code is present

******************************************************/

#ifndef SINGLY_LINKED_LIST0_H_INCLUDED
#define SINGLY_LINKED_LIST0_H_INCLUDED

#include<stdlib.h>
#include<stdio.h>


struct node{
    int data;
    struct node* link;
};



/*appends the value passed at the end, and returns the ROOT*/
int append(struct node **ROOT, int d){
    struct node* temp;
    temp = (struct node*)malloc(sizeof(struct node*));
    if(temp == NULL) return -1;

    temp->data = d;
    if(*ROOT == NULL){
        *ROOT = temp;
        temp->link = NULL;
    }
    else{
        struct node* p = *ROOT;
        while(p->link != NULL){
            p = p->link;
        }
        p->link = temp;
        temp->link = NULL;
    }

    return 1;
}

/*prints all the values in the LL*/
void print_all(struct node* ROOT){
    if(ROOT == NULL) printf("\nList is empty\n\n");
    struct node *temp;
    temp = ROOT;
    printf("\n");
    while(temp->link!=NULL){
        printf("%d-->", temp->data);
        temp = temp->link;
    }
    if(temp->link == NULL) printf("%d-->", temp->data);
}

/*Returns the lenght of LL*/
int len(struct node* ROOT){
    struct node* temp = ROOT;
    int countt = 0;
    if(ROOT == NULL) return countt;
    while(temp->link!=NULL){
        countt++;
        temp = temp->link;
    }
    if(temp->link == NULL) countt++;

    return countt;
}

/*Adds the node at the begining, returns the ROOT*/
int add_at_begining(struct node** ROOT, int d){
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    if(temp == NULL) return -1;

    temp->data = d;
    temp->link = NULL;
    if(*ROOT == NULL)*ROOT = temp;
    else{
        temp->link = *ROOT;
        *ROOT = temp;
    }

    return 1;
}

/*Adds at a particular position , returns the ROOT*/
int add_at_position(struct node** ROOT, int n, int d){
    if(n > len(*ROOT)) return 0;
    if(n == 1) add_at_begining(ROOT, d);
    else{
        struct node *temp;
        temp = (struct node*)malloc(sizeof(struct node));
        temp->data = d;
        struct node *p;
        p = *ROOT;
        int i = 1;
        while(i != n-1){
            p = p->link;
            i++;
        }
        struct node *q;
        q = p->link;
        p->link = temp;
        temp->link = q;
    }

    return 1;
}

/*Deletes the front node, returns the ROOT*/
int delete_fornt(struct node** ROOT){
    struct node *temp;
    if(*ROOT == NULL) return -1;
    else{
        temp = *ROOT;
        *ROOT = temp->link;
        temp->link = NULL;
        free(temp);
    }

    return 1;
}

/*Deletes the node at particular position, returns the ROOT*/


int delete_at_position(struct node** ROOT, int n){
    if(n > len(*ROOT)) return 0;
    if(*ROOT == NULL) return -1;
    if(n == 1) delete_fornt(ROOT);
    else{
        struct node *p;
        p = *ROOT;
        int i = 1;
        while(i != n-1){
            p = p->link;
            i++;
        }
        struct node *q;
        q = p->link;
        p->link = q->link;
        q->link = NULL;
        free(q);
    }

    return 1;
}



/*Swaps the data values at positions n, m passed, and returns  the ROOT*/
int swap_data(struct node** ROOT, int n, int m){
    if(*ROOT == NULL)  return 0;
    struct node *tempn;
    tempn = *ROOT;
    int i = 1;
    int temp_data;
    while(i < n){
        tempn = tempn->link;
        i++;
    }
    temp_data = tempn->data;

    i = 1;
    struct node *tempm;
    tempm = *ROOT;
    while(i < m){
        tempm = tempm->link;
        i++;
    }
    tempn->data = tempm->data;
    tempm->data = temp_data;

    return 1;
}

/*Reverses the passed LL, returns the ROOT*/

int reverse_list(struct node** ROOT){
    if(*ROOT == NULL) return 0;
    int i = 1;
    int n = len(*ROOT);
    while(i <= n/2){
        swap_data(ROOT, i, (n-i+1));
        i++;
    }

    return 1;
}

/*peeks at the particular position and returns the value present at their*/
int peek(struct node** ROOT, int pos){
    struct node* temp;
    temp = *ROOT;
    int i = 1;
    while(i < pos){
        temp = temp->link;
        i++;
    }

    return temp->data;
}

/*Bubble sorts the passed LL, returns the ROOT*/

int sort_bubble(struct node** ROOT, char mode){
    int n = len(*ROOT);
    for(int i=1;i<=n;i++){
        for(int j=i+1;j<=n;j++){
            if(peek(ROOT, i) > peek(ROOT, j) && mode == 'a') swap_data(ROOT, i, j);
            if(peek(ROOT, i) < peek(ROOT, j) && mode == 'd') swap_data(ROOT, i, j);
        }
    }

    return 1;
}


#endif // SINGLY_LINKED_LIST0_H_INCLUDED
