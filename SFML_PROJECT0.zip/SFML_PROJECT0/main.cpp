////////////IBRARIES
#include<SFML/window.hpp>
#include<SFML/graphics.hpp>
#include<iostream>
#include<fstream>

////////////MAIN
int main(){

///////////MAP_FILE
    std::string str;
    std::ifstream map_file;
    int x_margin =  20;
    int y_margin = 20;
    map_file.open("map.txt");
    char map_arr[10][10] ={};
    int y = 0;
    while(!map_file.eof()){
        getline(map_file, str);
        for(int x=0;x<x_margin;x++){
            switch (str[x]){
            case 'x': map_arr[x/2][y] = 'x';
                break;
            case '1': map_arr[x/2][y] = '1';
                break;
            case '2': map_arr[x/2][y] = '2';
                break;
            case '3': map_arr[x/2][y] = '3';
                break;
            default:
                break;
            }
        }
        y++;
    }


    sf::RenderWindow window(sf::VideoMode(640, 480), "window");
    window.setFramerateLimit(60);

    sf::Texture texture;
    sf::Sprite sprite;
    sprite.setTexture(texture);
    texture.loadFromFile("map_tiles.png");


    while(window.isOpen()){

        sf::Event event;
        while(window.pollEvent(event)){  //pollevent returns true if any event is pending
            switch(event.type){
            case sf::Event::Closed :
                window.close();
                break;
            default:
                break;
            }

        for(int y=0;y<y_margin/2;y++){
            for(int x=0;x<x_margin/2;x++){
                if(map_arr[x][y] == 'x'){//sky
                    sprite.setTextureRect(sf::IntRect(0, 0, 320, 240));
                    sprite.setScale(0.2, 0.2);
                    sprite.setPosition(x*64, y*48);
                }
                if(map_arr[x][y] == '1'){//grass
                    sprite.setTextureRect(sf::IntRect(320, 0, 640, 240));
                    sprite.setScale(0.2, 0.2);
                    sprite.setPosition(x*64, y*48);
                }
                if(map_arr[x][y] == '2'){//platform
                    sprite.setTextureRect(sf::IntRect(0, 240, 320, 480));
                    sprite.setScale(0.2, 0.2);
                    sprite.setPosition(x*64, y*48);
                }
                if(map_arr[x][y] == '3'){//soil
                    sprite.setTextureRect(sf::IntRect(320, 240, 640, 480));
                    sprite.setScale(0.2, 0.2);
                    sprite.setPosition(x*64, y*48);
                }
                window.draw(sprite);

            }
        }
        window.draw(sprite);
        window.display();
        }
    }

    return 0;
}

