#include <SFML/Graphics.hpp>
#include<fstream>
#include<iostream>

class player{  //plater class  a blue rectangle
public:
    int d = 4;
    int y_increment_positive = d;
    int y_increment_negative = -d;
    int x_increment_positive = d/2;
    int x_increment_negative = -d/2;

    int pg_no = 0;

    int j = 2;
    int initial;
    bool fall = false;


    void normal_status(){  //keeping things normal, have to make changes
         y_increment_positive = d;
         y_increment_negative = -d;
         x_increment_positive = d/2;
         x_increment_negative = -d/2;
    }

    int p_left, p_right, p_top, p_bottom;

    sf::RectangleShape rect;

    player(sf::Vector2f position, sf::Vector2f dimensions, sf::Color color){  //player onstructor
        rect.setSize(dimensions);
        rect.setPosition(position);
        rect.setFillColor(color);
    }

    void change_position(){  //keyboard instructions
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::A))
            rect.move(x_increment_negative, 0);
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::D))
            rect.move(x_increment_positive, 0);
        if(fall == false){
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
                y_increment_positive = 0;
                j = 1;
                if(p_bottom > initial - 120)rect.move(0, y_increment_negative);
            }
        }
        if(p_bottom == initial - 120){
            fall = true;
            j = 2;
        }
        rect.move(0, y_increment_positive);  //gravity
    }

    void update(){  //updating the boundaries of the player
        p_left = rect.getPosition().x;
        p_right = rect.getPosition().x + rect.getSize().x;
        p_top = rect.getPosition().y;
        p_bottom = rect.getPosition().y + rect.getSize().y;

        if(rect.getPosition().x > 640){
            pg_no++;
            rect.setPosition(0, rect.getPosition().y);
        }
    }

};

int main(){  //main
    std::string str;
    std::ifstream map_file;
    int x_margin =  60;
    int y_margin = 20;
    map_file.open("map.txt");
    char map_arr[30][10] ={};
    int y = 0;

    while(!map_file.eof()){  //making the map_array
        getline(map_file, str);
        for(int x=0;x<x_margin;x++){
            switch (str[x]){
            case 'x': map_arr[x/2][y] = 'x';
                break;
            case 'b': map_arr[x/2][y] = 'b';
                break;
            case 'g': map_arr[x/2][y] = 'g';
                break;
            case 's': map_arr[x/2][y] = 's';
                break;
            default:
                break;
            }
        }
        y++;
    }

    char col_arr[30][10] ={};
    std::fstream collision_file;
    collision_file.open("collision_map.txt");
    y = 0;
    while(!collision_file.eof()){  //making col_array
        getline(collision_file, str);
        for(int x=0;x<x_margin;x++){
            switch (str[x]){
            case '0': col_arr[x/2][y] = '0';
                break;
            case '1': col_arr[x/2][y] = '1';
                break;
            default:
                break;
            }
        }
        y++;
    }


    sf::RenderWindow window(sf::VideoMode(640, 480), "HAHAHAA");
    window.setFramerateLimit(60);

    sf::Texture texture_brick;  //setting-up sprites
    sf::Texture texture_sky;
    sf::Texture texture_gnd;
    sf::Sprite sprite_brick;
    sf::Sprite sprite_sky;
    sf::Sprite sprite_gnd;
    sprite_brick.setTexture(texture_brick);
    sprite_sky.setTexture(texture_sky);
    sprite_gnd.setTexture(texture_gnd);
    texture_brick.loadFromFile("brick_tile.png");
    texture_sky.loadFromFile("sky_tile.png");
    texture_gnd.loadFromFile("map_tiles.png");
    sprite_sky.setTextureRect(sf::IntRect(0, 0, 640, 480));
    sprite_brick.setTextureRect(sf::IntRect(0, 0, 64, 48));

    player play(sf::Vector2f(100, 100), sf::Vector2f(20, 20), sf::Color::Blue);  //player constructor

    while(window.isOpen()){  //game loop
        sf::Event event;
        while(window.pollEvent(event)) if(event.type == event.Closed) window.close();

        play.change_position();
        play.update();

        window.clear();
        window.draw(sprite_sky);
        for(int y=0;y<y_margin/2;y++){  //drawing sprites
            for(int x=play.pg_no;x<x_margin/2;x++){
                if(map_arr[x][y] == 'b'){
                    sprite_brick.setPosition((x - play.pg_no*10)*64, y*48);
                    window.draw(sprite_brick);
                }
                if(map_arr[x][y] == 'g'){
                    sprite_gnd.setTextureRect(sf::IntRect(320, 0, 640, 240));
                    sprite_gnd.setScale(0.2, 0.2);
                    sprite_gnd.setPosition((x - play.pg_no*10)*64, y*48);
                    window.draw(sprite_gnd);
                }
                if(map_arr[x][y] == 's'){
                    sprite_gnd.setTextureRect(sf::IntRect(320, 240, 640, 480));
                    sprite_gnd.setScale(0.2, 0.2);
                    sprite_gnd.setPosition((x - play.pg_no*10)*64, y*48);
                    window.draw(sprite_gnd);
                }
            }
        }

        play.normal_status();
        if(play.j == 2){  //setting up the initial(reference) point for the jump
            play.initial = play.p_bottom;
        }

        for(int j=0;j<y_margin/2;j++){  //collision check loop
            for(int i=0;i<x_margin/2;i++){
                if(col_arr[i][j] == '1'){
                    int left, right, top, bottom;
                    bottom = j * 48 + 48;
                    top = j * 48;
                    left = (i - play.pg_no * 10)* 64;
                    right = (i - play.pg_no * 10)* 64 + 64;

                    if(!(play.p_right < left || play.p_left > right||
                       play.p_top > bottom || play.p_bottom < top)){
                        //play.rect.setFillColor(sf::Color::Red);
                        if(play.p_bottom == top){
                            play.y_increment_positive = 0;
                            play.j = 2;
                            play.fall = false;
                            break;
                        }
                        if(play.p_top == bottom){
                            play.y_increment_negative = 0;
                            play.fall = true;
                            break;
                        }
                        if(play.p_right == left){
                            play.x_increment_positive = 0;
                            break;
                        }
                        if(play.p_left == right){
                            play.x_increment_negative = 0;
                            break;
                        }
                    }
                }
            }
        }

        window.draw(play.rect);
        window.display();
    }

    return 0;
}
//
