/*****************************************************
USERDEFINED LIBRARY FOR SIMPLE OPERATIONS ON SINGLY LINKED LISTS

---include it in the directory where the source code is present

******************************************************/




#ifndef SINGLY_LINKED_LIST0_H_INCLUDED
#define SINGLY_LINKED_LIST0_H_INCLUDED

#include<stdlib.h>
#include<stdio.h>
struct node{
    int data;
    struct node* link;
};

/*appends the value passed at the end, and returns the ROOT*/
struct node* append(struct node* ROOT, int d){
    struct node *temp;
    temp = (struct node*)malloc(sizeof(struct node));
    temp->data = d;
    temp->link = NULL;
    if(ROOT == NULL) ROOT = temp;
    else{
        struct node *p;
        p = ROOT;
        while(p->link != NULL){
            p = p->link;
        }
        p->link = temp;
    }

    return ROOT;
}

/*prints all the values in the LL*/
void print_all(struct node* ROOT){
    struct node *temp;
    temp = ROOT;
    if(ROOT == NULL)printf("\nList is empty\n\n");
    printf("\n");
    while(temp->link!=NULL){
        printf("%d-->", temp->data);
        temp = temp->link;
    }
    if(temp->link == NULL)printf("%d-->", temp->data);
}

/*Returns the lenght of LL*/
int len(struct node* ROOT){
    struct node* temp = ROOT;
    int count = 0;
    if(ROOT == NULL)return count;
    while(temp->link!=NULL){
        count++;
        temp = temp->link;
    }
    if(temp->link == NULL)count++;

    return count;
}

/*Adds the node at the begining, returns the ROOT*/
struct node* add_at_begining(struct node* ROOT, int d){
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = d;
    temp->link = NULL;
    if(ROOT == NULL)ROOT = temp;
    else{
        temp->link = ROOT;
        ROOT = temp;
    }

    return ROOT;
}

/*Adds at a particular position , returns the ROOT*/
struct node* add_at_position(struct node* ROOT, int n, int d){
    if(n > len(ROOT)){
        printf("\nInvalid position!\n\n");
        return ROOT;
    }
    if(n == 1){
        ROOT = add_at_begining(ROOT, d);
        return ROOT;
    }
    struct node *temp;
    temp = (struct node*)malloc(sizeof(struct node));
    temp->data = d;
    struct node *p;
    p = ROOT;
    int i = 1;
    while(i != n-1){
        p = p->link;
        i++;
    }
    struct node *q;
    q = p->link;
    p->link = temp;
    temp->link = q;

    return ROOT;
}

/*Deletes the front node, returns the ROOT*/
struct node* delete_fornt(struct node* ROOT){
    struct node *temp;
    if(ROOT == NULL)printf("\nList is empty\n\n");
    else{
        temp = ROOT;
        ROOT = temp->link;
        temp->link = NULL;
        free(temp);
    }

    return ROOT;
}

/*Deletes the node at particular position, returns the ROOT*/
struct node* delete_at_position(struct node* ROOT, int n){
    if(n > len(ROOT)){
        printf("\nInvalid position!\n\n");
        return ROOT;
    }
    if(ROOT == NULL){
        printf("\nList is empty\n\n");
        return ROOT;
    }
    if(n == 1){
        ROOT = delete_fornt(ROOT);
        return ROOT;
    }
    else{
        struct node *p;
        p = ROOT;
        int i = 1;
        while(i != n-1){
            p = p->link;
            i++;
        }
        struct node *q;
        q = p->link;
        p->link = q->link;
        q->link = NULL;
        free(q);
    }

    return ROOT;
}

/*Swaps the data values at positions n, m passed, and returns  the ROOT*/
struct node* swap_data(struct node* ROOT, int n, int m){
    if(ROOT == NULL){
        printf("\nList is empty\n\n");
        return ROOT;
    }
    struct node *tempn;
    tempn = ROOT;
    int i = 1;
    int temp_data;
    while(i < n){
        tempn = tempn->link;
        i++;
    }
    temp_data = tempn->data;

    i = 1;
    struct node *tempm;
    tempm = ROOT;
    while(i < m){
        tempm = tempm->link;
        i++;
    }
    tempn->data = tempm->data;
    tempm->data = temp_data;

    return ROOT;
}

/*Reverses the passed LL, returns the ROOT*/
struct node* reverse_list(struct node* ROOT){
    int i = 1;
    int n = len(ROOT);
    while(i <= n/2){
        ROOT = swap_data(ROOT, i, (n-i+1));
        i++;
    }

    return ROOT;
}

/*peeks at the particular position and returns the value present at their*/
int peek(struct node* ROOT, int pos){
    struct node* temp;
    temp = ROOT;
    int i = 1;
    while(i < pos){
        temp = temp->link;
        i++;
    }

    return temp->data;
}

/*Bubble sorts the passed LL, returns the ROOT*/
struct node* sort_bubble(struct node* ROOT){
    int n = len(ROOT);
    for(int i=1;i<=n;i++){
        for(int j=i+1;j<=n;j++){
            if(peek(ROOT, i) > peek(ROOT, j)){
                ROOT = swap_data(ROOT, i, j);
            }
        }
    }

    return ROOT;
}


#endif // SINGLY_LINKED_LIST0_H_INCLUDED
