#include<iostream>
#include<fstream>
#include<string>
#include<stdlib.h>
using namespace std;

class hotel{
public:
    int option;

    void menu();
    void def();
    void alloted_rooms();
    void book_room();
    void edit_record();
    void Exit();


};

void hotel::menu(){
    cout<<"\t\t\t#######################"<<endl;
    cout<<"\t\t\t         MENU          "<<endl;
    cout<<"\t\t\t 1. Alloted rooms"<<endl;
    cout<<"\t\t\t 2. Book a room"<<endl;
    cout<<"\t\t\t 3. Edit record"<<endl;
    cout<<"\t\t\t 4. Other "<<endl;
    cout<<"\t\t\t 5. Exit "<<endl;
    cout<<"\t\t\t#######################"<<endl;

    cin>>option;

    switch(option){
        case 1:alloted_rooms();
            break;
        case 2:book_room();
            break;
        case 3:edit_record();
            break;
        case 5:Exit();
            break;

        default: def();
    }
}

void hotel::alloted_rooms(){
    fstream file[3];
    string line;
    file[0].open("name.txt", ios::in);
    file[1].open("room.txt", ios::in);
    file[2].open("number.txt", ios::in);
    if(file[0].is_open()){
        cout<<"\t\t\t NAME \t\t ROOM \t\t NUMBER"<<endl;
        cout<<"\t\t\t ======================================================="<<endl<<endl;
        while(!(file[0].eof() || file[1].eof() || file[2].eof())){

            getline(file[0], line);
            cout<<"\t\t\t "<<line;

            getline(file[1], line);
            cout<<"\t\t "<<line;

            getline(file[2], line);
            cout<<"\t\t "<<line;

            cout<<endl<<"\t\t\t "<<"-------------------------------------------------------"<<endl;
        }
    }
    file[0].close();
    file[1].close();
    file[2].close();
    menu();
}

void hotel::book_room(){
    fstream file[3];
    string line;
    string room;
    file[1].open("room.txt", ios::in | ios::out | ios::app);
    cout<<endl<<"Enter the room to check validity:";
    cin>>room;

    while(!file[1].eof()){
        getline(file[1], line);
        if(room == line){
            cout<<"Room is already been occupied!!"<<endl;
            file[1].close();
            book_room();
        }
    }
    file[1].close();

    file[0].open("name.txt", ios::in | ios::out | ios::app);
    file[1].open("room.txt", ios::in | ios::out | ios::app);
    file[2].open("number.txt", ios::in | ios::out | ios::app);

    file[1]<<room<<endl;

    cout<<"Enter name: ";
    cin>>room;
    file[0]<<room<<endl;

    cout<<"Enter number: ";
    cin>>room;
    file[2]<<room<<endl;

    cout<<"Your details have been saved!!"<<endl;

    file[0].close();
    file[1].close();
    file[2].close();

    menu();
}

void hotel::edit_record(){
    string room, line;
    fstream file[3];
    fstream temp;
    cout<<"Enter room no. to delete: ";
    cin>>room;
    //////room_number deletion
    file[1].open("room.txt", ios::in);
    temp.open("temp.txt", ios::out);
    int i, n = 0;
    while(getline(file[1], line)){
        if(line != room){
            temp<<line<<endl;
            i++;
        }
        else n = i - 2;
    }
    temp.close();
    file[1].close();

    file[1].open("room.txt", ios::out);
    temp.open("temp.txt", ios::in);
    while(!temp.eof()){
        getline(temp, line);
        file[1]<<line<<endl;
    }
    temp.close();
    file[1].close();

    //////name deletion
    i = 0;
    file[0].open("name.txt", ios::in);
    temp.open("temp.txt", ios::out);
    while(!file[0].eof()){
        i++;
        getline(file[0], line);
        if(i != n)temp<<line<<endl;
        else continue;
    }
    temp.close();
    file[0].close();

    file[0].open("name.txt", ios::out);
    temp.open("temp.txt", ios::in);
    while(!temp.eof()){
        getline(temp, line);
        file[0]<<line<<endl;
    }
    temp.close();
    file[0].close();

    //////number deletion
    i = 0;
    file[2].open("number.txt", ios::in);
    temp.open("temp.txt", ios::out);
    while(!file[2].eof()){
        i++;
        getline(file[2], line);
        if(i != n)temp<<line<<endl;
        else continue;
    }
    temp.close();
    file[2].close();

    file[2].open("number.txt", ios::out);
    temp.open("temp.txt", ios::in);
    while(!temp.eof()){
        getline(temp, line);
        file[2]<<line<<endl;
    }
    temp.close();
    file[2].close();

    temp.open("temp.txt", ios::out);
    temp.close();
}

void hotel::def(){
    cout<<"\t\t\tInvalid option, choose again!!"<<endl;
    menu();
}

void hotel::Exit(){
    exit(0);
}


int main(){
    hotel costomer;
    costomer.menu();

    return 0;
}

